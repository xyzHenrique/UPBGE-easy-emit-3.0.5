EasyEmit_0.3
original author: Andreas Esau
edited by: Henrique Rodrigues
version: 0.3.0

#0.3 Bug fixes
-Fixed a graphic bug in the interface.
Resolvido um bug gr�fico na interface.

-It was fixed an error that when saving a .blend file, when loading this same file with the Particles, it was not possible to change that object anymore.
Foi arrumado um erro que ao salvar um arquivo .blend, ao carregar esse mesmo arquivo com as Particulas, n�o era possivel mais alterar aquele objeto.

-It has been arranged some code lines that are not interacting with UPBGE 0.2.4.
Foi arrumado umas linhas de c�digos que n�o est�o interagindo com a UPBGE 0.2.4.

-Fixed a graphic error in the interface that happened sometimes.
Foi corrigido um erro gr�fico na interface que acontecia as vezes.

official link: https://blenderartists.org/t/easyemit-update-13-06-2013/528897